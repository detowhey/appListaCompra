package br.com.qi.model

data class Produto(val id: Long, val nome: String, val preco: Double, val quantidade: Int)